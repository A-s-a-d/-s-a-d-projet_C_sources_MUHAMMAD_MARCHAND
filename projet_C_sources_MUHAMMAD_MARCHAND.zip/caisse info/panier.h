#ifndef PANIER_H_GUARD
#define PANIER_H_GUARD

#include "definitions.h"
#include "produits.h"
#include "utils.h"



/*
 * PANIER_PRODS_QTE contient la quantite de chaque produit du meme indice que
 * dans le tableau PRODUITS.
 * Par exemple, si PANIER_PRODS_QTE[3] == 2, alors c'est que le client a demande
 * d'acheter 2 lots de "LEGUMES" (voir produits.c).
 */
extern int     PANIER_PRODS_QTE[MAX_PRODUITS];

/*
 stocke la valeur de PRIX_TOTAL de PANIER en float
 */
extern float   PRIX_TOTAL                    ;

/*
 true ou false en en fonction de : si le client est fidel ou pas
 */
extern bool    CLIENT_FIDELE                 ;

/*
 * panier_remise_client
 * fonction :
 * entrees : entree de clavier
 * sortie : change le valieurs de CLIENT_FIDEL a true si client est fidel
            en lui camparant avec les personned de liste
 * variables globales modifiées :
 */
bool panier_remise_client(void);

/*
 * panier_initialiser
 * fonction :
 * entrees :
 * sortie : remetes le valeurs de pannier a celle de panier  vide, et client a infidel pour nouveau client
 * variables globales modifiées :
 */
void panier_initialiser(void);

/*
 * panier_afficher
 * fonction :
 * entrees :
 * sortie : affiche le contennu de pannier avec prix et quantite
 * variables globales modifiées :
 */
void panier_afficher(void);

/*
 * panier_payer
 * fonction :
 * entrees :
 * sortie :
 Demmande si si client est fidel si  Client_FIDEL = false
 sinon ou apres demander applique la remise en fonction de Client_FIDEL
 * variables globales modifiées :
 */
void panier_payer(void);

/*
 * panier_ajouter
 * fonction : Client_FIDEL
 * entrees :
 * sortie :
 permet d'ajouter les produits au pannier en fonction de nom et quantite demandee
 * variables globales modifiées :
 */
void panier_ajouter(void);

/*
 * panier_supprimer
 * fonction :
 * entrees :
 * sortie :
  permet de supprime les produits au pannier en fonction de nom et quantite demandee
 * variables globales modifiées :
 */
void panier_supprimer(void);

/*
 * panier_afficher
 * fonction :
 * entrees :
 * sortie : affiche le contennu de pannier avec prix et quantite
 * variables globales modifiées :
 */
void panier_afficher(void);
#endif // PANIER_H_GUARD
