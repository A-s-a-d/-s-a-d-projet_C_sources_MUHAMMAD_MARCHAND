/*


Dans le programme nous avons fait toutes les fonctions necessaire paour
    faire fonnctioner le programme,

Nous avons fait le chiffrement et dechiffrement, mais nous n'avons pas
    reussi a verifier si le fichier a deja et encryptee ou decryptee pour eviter le
    double encryption et decription, sinon lors des teste le fonctions crypto_dechiffrer();et
    crypto_chiffrer();. nous avons testerr en enlevant le d'abord crypto_chiffrer(); des commentaire en main,
    et on voit en fichier que ca chiffre bien, puis nous avons mis crypto_chiffrer();en commentaire et
    enlever crypto_dechiffrer(); de commentaire et demmarer le programme, la en verifiant le fichie client on voit que
    le fichier a bien et dechifree?

Nous n'avons pas demmandee la cle de chiffrement a cause de probleme precedent

pour resoudre le probleme nous avons essayer de mettre le ENCRYPTEE: devant chaque ligne si la ligne est encryptee
 pour ne pas l'encryptee ou decryptee plusieur fois mais nous n'avons pas reussi"

 !!!! mettre le nom de produit en MAJUSCULE. !!!

*/
#include "definitions.h"
void mettre_en_majuscules(char ch[])
{
    for (int i = 0; ch[i] != '\0'; ++i)
        ch[i] = toupper(ch[i]);
}

void afficher_menu() // affiche le menu client
{
    printf("----------------------------------------------------------------------\n");
    printf("Entrez votre choix :\n"
        "[0] Quitter\n"
        "[1] Afficher la liste des produits\n"
        "[2] Ajouter un produit au panier\n"
        "[3] Retirer un produit du panier\n"
        "[4] Afficher le contenu du panier\n"
        "[5] Appliquer remise client\n"
        "[6] Payer\n"
    );
}


int main(void)
{
    int reponse = -1;
    /* lit le fichier de base de donnees des clients, et le charge en memoire */
    printf("\t\t###################    DEBUT      ########################\n");

    //crypto_dechiffrer();
    printf("Chargement fichier clients...\n");
    ouvrir_fichier();
    personnes_remplir_liste();
    fermer_fichier();
    //crypto_chiffrer();


    // Menu client
    do {
        afficher_menu();
        reponse = 7;
        reponse = lire_int();

        switch(reponse) {
        case 0:
                break;
        case 1: produit_afficher_liste();
                break;
        case 2: panier_ajouter();
                break;
        case 3: panier_supprimer();
                break;
        case 4: panier_afficher();
                break;
        case 5: CLIENT_FIDELE = panier_remise_client();
                break;
        case 6: panier_payer();
                CLIENT_FIDELE = false;
                panier_initialiser(); //reinitialisee le panier apres payer
                break;
        case 7 : printf("entrer le choix");
                break;
        default: printf("Reponse incorrecte.\n");
        }
    } while (reponse != 0);
    puts("A bientot.");
//*/
}
