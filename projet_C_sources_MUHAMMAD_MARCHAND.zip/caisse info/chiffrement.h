#ifndef CHIFFREMENT_H_GUARD
#define CHIFFREMENT_H_GUARD

#include "definitions.h"

#define CLE_DEFAUT 26

extern int CLE;

/*
 * cette fonction pour demander a l'utilisateur la cle pour dechiffrer ou chiffrer
 entree : avec scanf un nombre
 sortie :
 */
void crypto_choix_cle(int);

/*
 * crypto_chiffrer
 * fonction : ouvrir_fichier, fermer fichier.

 * entrées : pas de parametre
 * sortie : pas de sortie mais modifie le fichier
 * variables globales modifiées
  lis le fichier puis chiffre puis copie dans un autre ficher et a la fin change
 le nom de ficher chiffrer avec client, et supprime le fichier client
 */
void crypto_chiffrer();

/*
 * crypto_dechiffrer
 * fonction :   ouvrir_fichier, fermer fichier.
 * entrées :pas de parametre
 * sortie : pas de sortie mais modifie le fichier
 * variables globales modifiées

 lis le fichier puis dechiffre puis copie dans un autre ficher et a la fin change
 le nom de ficher dechiffrer avec client, et supprime le fichier client.
 */
void crypto_dechiffrer();

#endif // CHIFFREMENT_H_GUARD
