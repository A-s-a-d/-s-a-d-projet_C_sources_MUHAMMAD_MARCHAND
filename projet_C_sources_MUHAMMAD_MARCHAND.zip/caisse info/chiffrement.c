#include "chiffrement.h"
#include "definitions.h"


int CLE = CLE_DEFAUT;

void crypto_initialiser_cle(int cle)
{
    CLE = cle;
}

void crypto_chiffrer()
{
     printf("+++++++++++++++++++++++chiffrement\n");
    ouvrir_fichier();
    CLE = 5;   //cle de chiffrement , nous n'avonns pas demandee a l'utilisateur pour tester le programme
    FILE *encrypted_file = fopen("encrypted.txt", "w"); //cree un nouveau fichier pour stockee les lignes encryptee
    char LIGNE[50]; //pour stockeer un ligne
    while (fgets(LIGNE, sizeof(LIGNE), CLIENTS)) //lire fichier ligne par ligne
    {
        int length = strlen(LIGNE); // stocke la longeur avant d'encryptee
        for(int i=0;i<length;i++)
        {
            // encryption
            if (isspace(LIGNE[i])) { // saute les espaces
                continue;
            }
            if (!isalpha(LIGNE[i]))  //encrypte les numero
                LIGNE[i] = ((LIGNE[i] - '0' )+ CLE) % 10 + '0';

            if(isupper(LIGNE[i])) // encrypte les caracteres
                LIGNE[i]=((LIGNE[i]-'A') + CLE) % 26 + 'A';
            else if(islower(LIGNE[i]))
                LIGNE[i]=((LIGNE[i]-'a') + CLE) % 26 + 'a';
        }
        fputs(LIGNE, encrypted_file); // copie le contenu de LIGNE encryptee dans l'autre fichier
    }
    fclose(CLIENTS);            // ferme le fichier
    fclose(encrypted_file);
    remove(NOM_BDD); // supprime le fichier original
    rename("encrypted.txt", NOM_BDD); // renome le fichier encryptee par client
    fermer_fichier();
}

void crypto_dechiffrer() // pour decryption on enleve la cle de chiffremet. le rest c'est la meme structure que chiffrement
{
       printf("+++++++++++++++++++++++dechiffrement\n");
    ouvrir_fichier();
    CLE = 5;
    FILE *decrypted_file = fopen("decrypted.txt", "w");
    char LIGNE[50];
    while (fgets(LIGNE, sizeof(LIGNE), CLIENTS))
    {
        int length = strlen(LIGNE);
        for(int i=0;i<length;i++)
        {

            if (isspace(LIGNE[i]))
            {
                continue;
            }
            if (!isalpha(LIGNE[i]))
                LIGNE[i] = ((LIGNE[i] - '0' )- CLE) % 10 + '0';

            if(isupper(LIGNE[i]))
                LIGNE[i]=((LIGNE[i]-'A') - CLE + 26) % 26 + 'A';
            else if(islower(LIGNE[i]))
                LIGNE[i]=((LIGNE[i]-'a') - CLE + 26) % 26 + 'a';
        }
        fputs(LIGNE, decrypted_file);
    }
    fclose(CLIENTS); // ferme le fichier
    fclose(decrypted_file);
    remove(NOM_BDD); // supprime le fichier original
    rename("decrypted.txt", NOM_BDD); // renome le fichier encryptee par client
    fermer_fichier();
}


