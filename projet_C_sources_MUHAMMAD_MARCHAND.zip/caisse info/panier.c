#include "panier.h"              // Inclue le fichier panier.h (header)
#include "personnes.h"				//Inclue le fichier prersonnes.h (header)
#include "produits.h"				//Inclue le fichier produit.h (header)

int     PANIER_PRODS_QTE[MAX_PRODUITS]  =   { 0 };  //Initialie et declare la variable PANIER_PRODS_QTE � 0
float   PRIX_TOTAL                      =     0.0;  //Initialie et declare la varible en  float PRIX_TOTAL � 0
bool    CLIENT_FIDELE                   =   false;  //Initialie et declarela varible en  float PRIX_TOTAL � 0
Personne p_recherchee;





bool panier_remise_client(void)
{
    printf("Est ce que c'est un client fidele?\n");
    printf("Ajouter le nom de client en tout en MAJUSCULE\n");
    scanf("%s %s %u", &p_recherchee.nom, &p_recherchee.pnom, &p_recherchee.tel);    //Permet de lire les charact�res et numero aux claviers
    getchar();                              // Consume le caracter de nouveau ligne

    for (int i = 0; p_recherchee.nom[i]; i++)   //Boucle "for" qui sert � mettre le nom et prenom et client en majuscule en utilisant toupper
    {
        p_recherchee.nom[i] = toupper(p_recherchee.nom[i]);
    }
    for (int i = 0; p_recherchee.pnom[i]; i++)
    {
        p_recherchee.pnom[i] = toupper(p_recherchee.pnom[i]);
    }
    printf("test : %s %s %u\n", p_recherchee.nom, p_recherchee.pnom, p_recherchee.tel);



    printf("Recherche du client fidele : %s %s %u\n", p_recherchee.nom, p_recherchee.pnom, p_recherchee.tel);
    /*
       boucle for compare les donn�es entrees par client avec celle qui ont etait copier de fichier si ca les trouve
       ca renvoie que client est fidel sinon client reste in fidel

    */
    for (int i = 0; i < MAX_PERSONNES; i++)
    {
        if (strcmp(PERSONNES[i].nom, p_recherchee.nom) == 0 &&
                strcmp(PERSONNES[i].pnom, p_recherchee.pnom) == 0 &&
                PERSONNES[i].tel == p_recherchee.tel)
        {
            CLIENT_FIDELE = true;
            printf("Client cherchee est fidele .\n");
            return true;
        }
    }
    printf("client cherchee n'est pas fidele\n");
    return false;
}




void panier_initialiser(void)
{
    //Boucle "for" qui permet de reset le panier une fois que le client paye
    for (int i = 0; i < MAX_PRODUITS; ++i)
    {
        PANIER_PRODS_QTE[i] = 0;
        PRIX_TOTAL = 0.;
    }
    printf("----------------------------------------------------------------------\n");
    printf("##### Program et panier ont ete reinitialisee #####\n");

}


/*
Fonction qui permet d'afficher le pannier avec le prix et
leur quantite et 2 valeurs apres la virgule avec %.2fn
*/
void panier_afficher(void)
{

    printf("----------------------------------------------------------------------\n");
     printf("Produit\t\tQuantite\tPrix Unitaire\tTotal\n");

    for (int i = 0; i < NB_PRODS; i++)
    {
        if (PANIER_PRODS_QTE[i] > 0)
        {
            printf("%s\t\t%d\t\t%.2f\t\t%.2f\n",
                   NOMS_PRODUITS[i], PANIER_PRODS_QTE[i], PRIX_PRODUITS[i],
                   PANIER_PRODS_QTE[i] * PRIX_PRODUITS[i]);
        }
    }
    printf("\nTotal du panier: %.2f\n", PRIX_TOTAL);
    printf("----------------------------------------------------------------------\n");
/*
j'ai fais ca
*/
}



void panier_payer(void)
{
    float prix = PRIX_TOTAL;
    panier_afficher();

    /*
        bouclr qui demande si le client est fid�le ou non
        si le client n'a pas deja indiquee avec option 5
        puis verifie de meme facon que panier_remise_client();
        si le client est fidel ou pas

    */
    if (!CLIENT_FIDELE)
    {
        printf("Faites-vous partie du programme fidelite ? (o/n) ");
        char REPONSE = lire_char();
        if (REPONSE == 'o')
        {
            printf("Entrez votre nom, prenom et telephone : ");
            scanf("%s %s %u", p_recherchee.nom, p_recherchee.pnom, &p_recherchee.tel);
            for (int i = 0; p_recherchee.nom[i]; i++)
            {
                p_recherchee.nom[i] = toupper(p_recherchee.nom[i]);
            }
            for (int i = 0; p_recherchee.pnom[i]; i++)
            {
                p_recherchee.pnom[i] = toupper(p_recherchee.pnom[i]);
            }
            printf("Recherche du client : %s %s %u\n", p_recherchee.nom, p_recherchee.pnom, p_recherchee.tel);
            for (int i = 0; i < MAX_PERSONNES; i++)
            {
                if (strcmp(PERSONNES[i].nom, p_recherchee.nom) == 0 &&
                        strcmp(PERSONNES[i].pnom, p_recherchee.pnom) == 0 &&
                        PERSONNES[i].tel == p_recherchee.tel)
                {
                    CLIENT_FIDELE = true;
                    printf("Client cherchee est fidele.\n");
                    break;
                } else     printf("client cherchee n'est pas fidele\n");
                break;


            }
        }

    }

    /*
       Si le client est fid�le alors une remise est appliqu�e sur leur produits en fonction de prix.
        */
    if (CLIENT_FIDELE)
    {
        float remise = 0.0;
        if        (prix >= 80)
        {
            prix *= .90;
            remise = 10;
        } else if (prix >= 15)
            {
                prix *= .95;
                remise = 5;
            }
        printf("Total apres remise : %.2f (%.0f%% de remise)\n",prix,remise);
    }

    if (!CLIENT_FIDELE)
    {
        float remise = 0.0;
        printf("----------------------------------------------------------------------\n");
        printf("Total apres remise : %.2f (%.0f%% de remise)\n",prix,remise);
    }
        printf("Paiement effectue avec succes.\n");

        return main();      //renvoie a main pour redemarer le programme

}



